# Kaggle Setup Guide: Python Roguelike RL Environment

## Overview

This folder contains a complete, 1-to-1 Python translation of the C# roguelike core gameplay,
wrapped in a [Gymnasium](https://gymnasium.farama.org/) environment ready for training RL agents on Kaggle.

---

## Folder Structure

```
python_roguelike/
├── GameData.json            ← Game configuration (enemies, cards, relics, events, rooms)
├── requirements.txt         ← Minimal Python dependencies
├── data_loader.py           ← Loads GameData.json into typed pools
├── data/                    ← All data classes and enums (1:1 with C# data layer)
│   ├── enums.py
│   ├── card_data.py
│   ├── ...
│   ├── combatant/
│   ├── event/
│   └── pools/
├── core/                    ← Core game logic (1:1 with C# Roguelike.Core project)
│   ├── combat_manager.py
│   ├── game_controller.py
│   ├── game_run.py
│   ├── map/
│   ├── rooms/
│   └── ai/
│       ├── heuristic_player_ai.py   ← Built-in heuristic baseline agent
│       └── i_player_agent.py
└── env/
    └── roguelike_env.py     ← Gymnasium environment wrapper
```

---

## Step 1 — Upload to Kaggle as a Dataset

1. Zip the entire `python_roguelike/` folder:
   - On Windows: right-click → "Send to" → "Compressed (zipped) folder"
   - Or run: `python -m zipfile -c python_roguelike.zip python_roguelike/`

2. Go to [https://www.kaggle.com/datasets](https://www.kaggle.com/datasets) → **New Dataset**

3. Upload `python_roguelike.zip`, set the title (e.g., `roguelike-rl-env`), and publish.

---

## Step 2 — Kaggle Notebook Setup

In your Kaggle notebook, add your dataset under **Add Data** and then:

```python
# Install dependencies (Kaggle has numpy pre-installed)
!pip install gymnasium --quiet

import sys
sys.path.insert(0, "/kaggle/input/roguelike-rl-env")
```

---

## Step 3 — Create and Test the Environment

```python
from python_roguelike.env import RoguelikeEnv

env = RoguelikeEnv(seed=42, render_mode="ansi")

obs, info = env.reset()
print("Observation shape:", obs.shape)   # (OBS_DIM,) float32
print("Action space:", env.action_space) # Discrete(N)
print("Initial info:", info)
```

---

## Step 4 — Random Agent Loop

```python
import numpy as np

obs, info = env.reset(seed=0)
total_reward = 0.0

for step in range(500):
    action = env.action_space.sample()   # random action
    obs, reward, terminated, truncated, info = env.step(action)
    total_reward += reward
    if terminated or truncated:
        print(f"Episode ended at step {step}. Total reward: {total_reward:.2f}")
        print("Final info:", info)
        break
```

---

## Step 5 — Heuristic Baseline Agent

The built-in `HeuristicPlayerAI` plays optimally within its programmed rules and serves
as a strong baseline:

```python
from python_roguelike.core.ai.heuristic_player_ai import HeuristicPlayerAI
from python_roguelike.data_loader import load_game_data
from python_roguelike.core.game_controller import GameController
from python_roguelike.data.enums import GameState

json_path = "/kaggle/input/roguelike-rl-env/python_roguelike/GameData.json"
card_pool, relic_pool, enemy_pool, effect_pool, event_pool, room_configs, hero_data = load_game_data(json_path)

controller = GameController(card_pool, relic_pool, enemy_pool, effect_pool, event_pool, room_configs)
ai = HeuristicPlayerAI()
controller.start_new_run(seed=42, hero_data=hero_data)

run = controller.current_run
while run.current_state != GameState.GameOver:
    ai.take_action(controller)

print("Run complete! Floors cleared:", run.current_floor)
print("Hero HP:", run.the_hero.current_health, "/", run.the_hero.max_health)
```

---

## Step 6 — Training with Stable-Baselines3 (Recommended)

```python
!pip install stable-baselines3 --quiet

from stable_baselines3 import PPO
from python_roguelike.env import RoguelikeEnv

env = RoguelikeEnv(seed=42)
model = PPO(
    "MlpPolicy",
    env,
    verbose=1,
    n_steps=2048,
    batch_size=64,
    n_epochs=10,
    learning_rate=3e-4,
    gamma=0.99,
)
model.learn(total_timesteps=500_000)
model.save("roguelike_ppo")
```

To continue training or evaluate:

```python
model = PPO.load("roguelike_ppo")
obs, info = env.reset()
done = False
while not done:
    action, _ = model.predict(obs, deterministic=True)
    obs, reward, terminated, truncated, info = env.step(int(action))
    done = terminated or truncated
print("Final floor:", info["floor"])
```

---

## Step 7 — Action Masked PPO (Advanced, better performance)

If you want to use action masking (recommended — greatly improves learning efficiency):

```python
!pip install sb3-contrib --quiet

from sb3_contrib import MaskablePPO
from sb3_contrib.common.wrappers import ActionMasker

def mask_fn(env):
    return env.action_masks()

masked_env = ActionMasker(env, mask_fn)
model = MaskablePPO("MlpPolicy", masked_env, verbose=1)
model.learn(total_timesteps=500_000)
```

---

## Observation Space

Shape: `(153,)` float32 array, all values in [0.0, 1.0].

| Slice           | Description                                           |
|-----------------|-------------------------------------------------------|
| `[0:4]`         | Hero: hp_pct, block_pct, mana_pct, gold (normalized)  |
| `[4:11]`        | Hero active status effects (one-hot per effect type)  |
| `[11:61]`       | Hand: up to 10 cards × 5 features each                |
| `[61:101]`      | Master deck: up to 40 cards (star rating normalized)  |
| `[101:121]`     | Enemies: up to 4 × 5 features each                   |
| `[121:131]`     | Relics: up to 10, star rating normalized              |
| `[131:138]`     | Game state one-hot (7 states)                        |
| `[138:152]`     | Map nodes: up to 7 × (type_id, star)                 |
| `[152]`         | Current floor normalized                              |

---

## Action Space

`Discrete(ACT_DIM)` — actions outside the current game state are ignored (no-ops).

| Range                | Meaning                                              |
|----------------------|------------------------------------------------------|
| 0                    | End combat turn                                      |
| 1 – H×E              | Play card `h` targeting enemy `e` (H=10, E=4)       |
| H×E+1 – +N_NODES     | Choose map node (slot 0–6)                           |
| +N_NODES – +3        | Choose event option 0–2                              |
| following 5          | Confirm reward: skip or pick card 0–3               |
| following 5          | Buy shop card slot 0–4                              |
| following 5          | Buy shop relic slot 0–4                             |
| last                 | Leave shop                                           |

---

## Reward Shaping

| Event                        | Reward           |
|------------------------------|------------------|
| HP gain per point            | +0.10            |
| HP loss per point            | −0.10            |
| Gold gained (per gold)       | +0.02            |
| Floor advanced               | +5.0             |
| Each step                    | −0.01            |
| Win (game over, alive)       | +200 + floors×10 + hp_pct×50 |
| Lose (game over, dead)       | −50.0            |

---

## Tips

- **Use `action_masks()`** with MaskablePPO — the raw action space has many invalid actions,
  masking dramatically speeds up training.
- **Increase `max_steps`** if your training episodes truncate too early (default: 10,000).
- **Multiple parallel envs**: wrap with `stable_baselines3.common.vec_env.SubprocVecEnv` for
  faster data collection.
- **Curriculum**: start with `seed=i` for `i` in `range(N)` to ensure diverse maps.
- The `HeuristicPlayerAI` achieves a reasonable win rate and can be used as an imitation
  learning teacher or a comparison benchmark.
